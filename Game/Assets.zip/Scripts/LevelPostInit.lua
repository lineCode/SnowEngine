--========================================================================
-- ActorManager.lua : Executed after initializing the level


require("scripts\\Events.lua");

RegisterListeners();

